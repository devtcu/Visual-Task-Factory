# TENNIS 3D: multi-camera line call (Innodata Visual Task Factory)

**Short version:** three camera views of one tennis shot. Question: how many centimetres inside or outside the line
did the ball land? Across 2 models x 2 settings (20 answers), **only 1 answer was right**. Without the pictures,
both models refuse every time.

---

## 1. The task

Each task has 3 photos of the same shot, rendered from a 3D scene at the same instants:
- CAM 1: broadcast camera behind the near baseline;
- CAM 2: high side camera in the stands;
- CAM 3: low camera behind the far corner.

The ball is drawn at 17 numbered instants, 60 ms apart (same number = same instant in every photo). No camera
positions are given. All ITF court sizes are printed in the question (court length, line widths, net height, ball size).

Question: *"What is the signed distance, in centimetres, from the bounce contact point to the nearest OUTER edge of
the singles court boundary? Positive if inside, negative if outside."*

This is how Hawk-Eye works in real tennis: calibrate each camera from the known court lines, triangulate the ball
in 3D, fit the flight, find the bounce. (Owens, Harris & Stennett 2003; Hartley & Zisserman, Multiple View Geometry.)

### How the answer key is made
- The ball path is simulated in 3D (speed, spin, drag), and the bounce point comes from that, before anything is drawn.
- A second check recomputes the answer through the full camera pipeline (calibrate from court keypoints,
  triangulate, fit). It agrees within about 1 cm (`checks.recomputed_cm` in tasks.jsonl).
- The tolerance (±5 or ±10 cm) is the 95th percentile of that pipeline's error under pixel noise, over 300 runs
  (`tolerance_from` in metadata.jsonl).

## 2. Results (via OpenRouter, temperature 0)

| Task | Answer | Claude, high effort | Claude, capped | GPT, high effort | GPT, capped |
|---|---|---|---|---|---|
| tennis3d_01 | 16.4 ±10 | cut off (64k rerun: -55) | 380 | **18 ✓** | 5 |
| tennis3d_02 | 11.1 ±5 | -20 | 5 | -15 | -28 |
| tennis3d_03 | 41.5 ±5 | cut off (64k rerun: 65) | 11 | 0 | 10 |
| tennis3d_04 | 25.8 ±10 | 10 | -5 | -27 | -10 |
| tennis3d_05 | 28.0 ±5 | cut off (also at 64k) | 15 | -10 | 20 |
| **Right** | | **0/5** | **0/5** | **1/5** | **0/5** |

Settings:
- **High effort:** reasoning effort high, max 32,000 tokens.
- **Capped:** max 64,000 tokens with thinking capped at 40,000, so the model always has room to answer.
  Every capped reply finished.

**No picture:** both models refused all 5 (10/10 "cannot determine"), so the images are needed.

### What we learned
- **More thinking does not help.** On high effort Claude spent 28,000-64,000 tokens trying to do the 3D maths and
  still missed by 24-70 cm, or ran out of room. Capped, both models thought for only 3,000-7,000 tokens and also missed.
- **They cannot tell in from out.** Every ball is IN, but 8 of 19 numeric answers said OUT (negative).
- **The one right answer is likely luck:** GPT's 18 vs 16.4 falls inside the wider ±10 cm window.
- "Cut off" = Claude spent the whole token limit thinking and wrote no answer. We report it, then re-ran with a
  thinking cap so every reply finishes.

## 3. Open issues (fix before submitting)

1. **The generator code is not in this folder.** The tasks name `tennis_3d.corner_task` (version tennis-3d-1.0),
   but only the 5 finished tasks were shared. Without the code, judges cannot regenerate from a seed or rebuild in
   Docker. **Add the generator.**
2. **All 5 balls are IN, by 11-42 cm.** A constant guess of 16 cm would score 3/5 (tasks 01, 02, 04). Add OUT
   balls and closer calls so answers spread across negative and positive.
3. **Seed 3 is missing** (seeds 0, 1, 2, 4, 5). Probably rejected by the generator's own check; confirm.
4. **Not checkable by eye.** The answer needs camera calibration maths, not just looking. The defence: it is
   exactly how Hawk-Eye works, every court size is printed, and the second pipeline check reproduces every answer.
   Still weaker on "visually verifiable" than the fiber and factory tasks.
5. Two tolerances (±5 and ±10 cm) come from the noise test per task; say so in the submission.

## 4. Files

| Path | What it is |
|---|---|
| `tasks/tasks.jsonl` | 5 tasks: question, answer, tolerance, seed, checks (as received from the teammate, unchanged) |
| `tasks/metadata.jsonl` | Full scene data: ball path, frame times, camera positions, keypoints, tolerance method |
| `tasks/images/` | 15 images (3 cameras x 5 tasks), 1920x1144 |
| `results/responses_high_effort.csv` | Both models, high effort (Claude 3 of 5 cut off) |
| `results/responses_no_picture.csv` | Both models, no image (all refused) |
| `results/raw_capped/` | Both models, capped thinking (all finished) |
| `results/raw_claude_64k_rerun/` | Claude's 3 cut-off tasks re-run at 64,000 tokens |
| `results/raw_high_effort/` | Raw replies for the high-effort run |
| `results/run_config.json` | Endpoint, models, prompt template, settings |

Note for re-running with our eval code: `tasks.jsonl` stores the 3 images as a list under `image`; our runner reads
lists from an `images` field, so we copied that field across before running. Questions and answers were not changed.

## 5. For the final 10

Use 1 task as the hardest showpiece (for example **tennis3d_03**: answer 41.5 cm IN; the four answers were 65, 11, 0 and 10),
once the generator code is added. Keep the main weight on the factory-heads and fiber tasks, which are both hard and
easy to check by eye.
