"""Copied evaluator report support."""
