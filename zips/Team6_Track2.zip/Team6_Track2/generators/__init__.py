"""Task factory generator namespace."""
