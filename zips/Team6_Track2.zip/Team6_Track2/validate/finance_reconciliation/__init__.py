"""Finance reconciliation handoff validator."""
