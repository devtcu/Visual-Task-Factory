"""Handoff validation packages."""
